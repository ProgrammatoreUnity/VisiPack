particle minecraft:end_rod ~ ~ ~ 0 0 0 0 1
scoreboard players set #h.nfehx37wb example.tmp 0
execute unless block ~ ~ ~ #minecraft:air run scoreboard players set #h.nfehx37wb example.tmp 1
execute if score #h.nfehx37wb example.tmp matches 1 run function example:_gen/wand/use/rayhit_nfehx37wb
scoreboard players remove #r.nfehx37wb example.tmp 1
execute if score #h.nfehx37wb example.tmp matches 0 if score #r.nfehx37wb example.tmp matches ..0 run title @s actionbar {text:"Too far away!",color:"red"}
execute if score #h.nfehx37wb example.tmp matches 0 if score #r.nfehx37wb example.tmp matches 1.. positioned ^ ^ ^0.5 run function example:_gen/wand/use/ray_nfehx37wb
