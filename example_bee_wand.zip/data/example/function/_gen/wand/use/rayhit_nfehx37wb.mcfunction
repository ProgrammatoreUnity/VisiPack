summon minecraft:bee ~ ~1 ~ {Tags:["example.helper"],CustomName:{text:"Helper Bee",color:"yellow"}}
playsound minecraft:block.amethyst_block.chime master @a ~ ~ ~ 1 1.4
scoreboard players add @s example.bees_summoned 1
