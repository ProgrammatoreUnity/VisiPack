# Uninstall: /function example:uninstall, then remove the pack
schedule clear example:timer/second
scoreboard objectives remove example.tmp
scoreboard objectives remove example.var
scoreboard objectives remove example.bees_summoned
scoreboard objectives remove example.use.carrot
scoreboard objectives remove menu
tellraw @s {text:"Data pack \"Example: Bee Wand\" uninstalled. You can now turn it off with /datapack disable.",color:"yellow"}
