# Player events (join, death, right-click, trigger)
execute as @a[scores={example.use.carrot=1..}] at @s if items entity @s weapon.* minecraft:carrot_on_a_stick[minecraft:custom_data~{bee_wand:1b}] run function example:wand/use
execute as @a[tag=!example.joined.welcome_join] at @s run function example:welcome/join
scoreboard players enable @a menu
execute as @a[scores={menu=1..}] at @s run function example:timer/menu
scoreboard players reset @a[scores={menu=1..}] menu
scoreboard players reset @a[scores={example.use.carrot=1..}] example.use.carrot
